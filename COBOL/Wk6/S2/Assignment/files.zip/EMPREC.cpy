      *> AUTHOR: Gideon Kipamet Kaiyian
      *> DATE: July 29, 2026
      *> PURPOSE: Shared EMPLOYEE-RECORD layout, COPYed into the main
      *>          program's WORKING-STORAGE and into COMPUTE-GROSS's
      *>          LINKAGE SECTION - the only subprogram that needs
      *>          the raw employee fields.

       01  EMPLOYEE-RECORD.
           05 EMP-ID              PIC X(5).
           05 EMP-NAME             PIC X(20).
           05 EMP-BASIC             PIC 9(7)V99.
           05 EMP-ALLOWANCES        PIC 9(6)V99.
